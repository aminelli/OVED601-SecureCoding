
namespace OnlineBankingApp.Services
{
    public class LdapConfig
    {
        public string Path { get; set; }
        public string UserDomainName { get; set; }
    }
}